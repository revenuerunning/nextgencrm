import { QuestionMarkCircledIcon } from "@radix-ui/react-icons";

export const statuses = [
  {
    value: "new",
    label: "New",
    icon: QuestionMarkCircledIcon,
  },
];
